package SESurvey;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Scanner;
import org.json.JSONObject;

public class SurveyExtIns {
  public static Connection DBConnection() {
    Connection connect = null;
    String ConnectionHost = "3.82.210.103";
    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
      connect = DriverManager.getConnection("jdbc:mysql://" + ConnectionHost + ":3306/MERIDB?" + "user=CS370&password=HelloCat1");
      System.out.println("Connection to Database Successful!");
    } catch (Exception e) {
      try {
        throw e;
      } catch (Exception e1) {
        e1.printStackTrace();
      } 
    } 
    return connect;
  }
  
  public static boolean ExpDateCheck(Connection connect, String S_ID, String User_ID) {
    PreparedStatement PS = null;
    Calendar date = Calendar.getInstance();
    Calendar today = Calendar.getInstance();
    try {
      String query1 = "Select Expiration_date\r\nfrom UserSurvey \r\nwhere Survey_ID = '" + 
        
        S_ID + "' AND User_ID = '" + User_ID + "'";
      PS = connect.prepareStatement(query1);
      ResultSet result = PS.executeQuery();
      if (result.next()) {
        query1 = "Select year(Expiration_date)\r\nfrom UserSurvey \r\nwhere Survey_ID = '" + 
          
          S_ID + "' AND User_ID = '" + User_ID + "'";
        PS = connect.prepareStatement(query1);
        result = PS.executeQuery();
        result.next();
        int year = result.getInt(1);
        query1 = "Select month(Expiration_date)\r\nfrom UserSurvey \r\nwhere Survey_ID = '" + 
          
          S_ID + "' AND User_ID = '" + User_ID + "'";
        PS = connect.prepareStatement(query1);
        result = PS.executeQuery();
        result.next();
        int month = result.getInt(1) - 1;
        query1 = "Select day(Expiration_date)\r\nfrom UserSurvey \r\nwhere Survey_ID = '" + 
          
          S_ID + "' AND User_ID = '" + User_ID + "'";
        PS = connect.prepareStatement(query1);
        result = PS.executeQuery();
        result.next();
        int day = result.getInt(1);
        date.set(year, month, day);
      } else {
        System.out.println("User Survey Not found.");
        return false;
      } 
      if (date.compareTo(today) < 0) {
        System.out.println("Sorry this survey has expired.");
        return false;
      } 
    } catch (Exception e) {
      try {
        throw e;
      } catch (Exception e1) {
        e1.printStackTrace();
      } 
    } 
    return true;
  }
  
  public static JSONObject SurveyTest(Connection connect, String S_ID, String User_ID) {
    PreparedStatement PS = null;
    JSONObject Survey1 = new JSONObject();
    try {
      int questionNum = 1;
      int qcNum = 1;
      Survey1.put("SurveyID", S_ID);
      Survey1.put("UserID", User_ID);
      String query1 = "Select Title\r\nFrom Survey\r\nwhere Survey_ID = '" + S_ID +"'";
      PS = connect.prepareStatement(query1);
      ResultSet result = PS.executeQuery();
      result.next();
      Survey1.put("SurveyTitle", result.getString(1));
      query1 = "Select Description\r\nFrom Survey\r\nwhere Survey_ID = '" + S_ID +"'";
      PS = connect.prepareStatement(query1);
      result = PS.executeQuery();
      result.next();
      Survey1.put("Survey Description", result.getString(1));
      query1 = "Select QID\r\nfrom Question\r\nwhere Survey_ID = '" +  S_ID + "'";
      PS = connect.prepareStatement(query1);
      result = PS.executeQuery();
      while (result.next()) {
        Survey1.put("Question " + questionNum, new JSONObject());
        JSONObject reference = Survey1.getJSONObject("Question " + questionNum);
        reference.put("QID", result.getInt(1));
        query1 = "Select Qdescription\r\nfrom Question\r\nWhere QID = '" + 
          
          reference.get("QID") + "'";
        PS = connect.prepareStatement(query1);
        ResultSet result2 = PS.executeQuery();
        result2.next();
        reference.put("Question Description", result2.getString(1));
        query1 = "Select QCID\r\nfrom QuestionChoices\r\nWhere QID = '" + 
          
          reference.get("QID") + "'";
        PS = connect.prepareStatement(query1);
        result2 = PS.executeQuery();
        while (result2.next()) {
          reference.put("QC" + qcNum, new JSONObject());
          JSONObject reference2 = reference.getJSONObject("QC" + qcNum);
          reference2.put("QCID", result2.getInt(1));
          query1 = "Select Type_ID\r\nfrom Question\r\nWhere QID = '" + 
            
            reference.get("QID") + "'";
          PS = connect.prepareStatement(query1);
          ResultSet result3 = PS.executeQuery();
          result3.next();
          reference2.put("TypeID", result3.getInt(1));
          query1 = "Select Type_def\r\nfrom ResponceType\r\nWhere Type_ID = '" + 
            
            reference2.get("TypeID") + "'";
          PS = connect.prepareStatement(query1);
          result3 = PS.executeQuery();
          result3.next();
          reference2.put("TypeDef", result3.getString(1));
          query1 = "Select Choice_val\r\nfrom QuestionChoices\r\nWhere QCID = '" + 
            
            reference2.get("QCID") + "'";
          PS = connect.prepareStatement(query1);
          result3 = PS.executeQuery();
          result3.next();
          reference2.put("ChoiceVal", result3.getString(1));
          query1 = "Select Descrip\r\nfrom QuestionChoices\r\nWhere QCID = '" + 
            
            reference2.get("QCID") + "'";
          PS = connect.prepareStatement(query1);
          result3 = PS.executeQuery();
          result3.next();
          reference2.put("QCDescrip", result3.getString(1));
          qcNum++;
        } 
        qcNum = 1;
        questionNum++;
      } 
    } catch (Exception e) {
      try {
        throw e;
      } catch (Exception e1) {
        e1.printStackTrace();
      } 
    } 
    return Survey1;
  }
  
  public static void ResponseInsert(File file, Connection connect) throws SQLException {
    try {
      PreparedStatement PS = null;
      Scanner scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        String[] line = scanner.nextLine().split("#");
        String QRID = String.valueOf(line[0]) + line[1] + line[2];
        String QID = line[2];
        String User_ID = line[1];
        String Type_ID = line[3];
        String Responce = line[4];
        String query1 = "Select QRID from QResponce\r\nwhere User_ID= '" + 
          User_ID + "' and QID = '" + QID + "'";
        PS = connect.prepareStatement(query1);
        ResultSet result = PS.executeQuery();
        if (!result.next()) {
          if (Integer.parseInt(Type_ID) == 3) {
            query1 = "insert into QResponce (QRID, QID, User_ID, Text)\r\nvalues (?,?,?,?)";
            PS = connect.prepareStatement(query1);
            PS.setInt(1, Integer.parseInt(QRID));
            PS.setInt(2, Integer.parseInt(QID));
            PS.setInt(3, Integer.parseInt(User_ID));
            PS.setString(4, Responce);
            PS.execute();
            System.out.println("insert Successful");
            continue;
          } 
          query1 = "insert into QResponce (QRID, QID, User_ID, Responce_val)\r\nvalues (?,?,?,?)";
          PS = connect.prepareStatement(query1);
          PS.setInt(1, Integer.parseInt(QRID));
          PS.setInt(2, Integer.parseInt(QID));
          PS.setInt(3, Integer.parseInt(User_ID));
          PS.setString(4, Responce);
          PS.execute();
          System.out.println("insert Successful");
          continue;
        } 
        System.out.println("Response already exists");
      } 
      scanner.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } 
  }
  public static void main(String[] args) {
		SurveyExtIns Survey = new SurveyExtIns();
		Connection connect = Survey.DBConnection();
		String S_ID = "987";
		String User_ID = "123";	
		if(Survey.ExpDateCheck(connect,S_ID, User_ID)) {
			JSONObject Survey1 = Survey.SurveyTest(connect,S_ID, User_ID);
			try {
				File jsonfile = new File("C:\\Users\\cindy\\Desktop\\eclipse\\JSONSurvey.txt");
				System.out.println("File created Successfully");
				FileWriter file = new FileWriter(jsonfile);
				file.write(Survey1.toString(5));
				System.out.println("JSON added successfully");
				try {
					Survey.ResponseInsert(new File("C:\\Users\\cindy\\Desktop\\eclipse\\responceexample.txt"), connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				file.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
}
