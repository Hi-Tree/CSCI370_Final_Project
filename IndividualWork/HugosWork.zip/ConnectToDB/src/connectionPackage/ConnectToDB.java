package connectionPackage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class ConnectToDB {
	private String ipAddress, database, dbUser, dbUPassword;
	private String url = "";
	public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	private Connection connection = null;
	private File repoLocation;

	// Twilio variables
	public static final String ACCOUNT_SID = "ACcf20c38fe658e8fd559d6f44608e82c0";
	public static final String AUTH_TOKEN = "12b1db01c89d1c12214a8c0e36a9d171";
	// Note for myself: both SID and Token should be stored in a secure place (like
	// environment variables). Ask professor about it.

	public String servletLocation = "http://52.15.52.238:8080/SurveyRetrieve/surveys?";

	/*
	 * Constructor
	 */
	public ConnectToDB(String ip, String db, String dbu, String pswr, File rp) {
		ipAddress = ip;
		database = db;
		dbUser = dbu;
		dbUPassword = pswr;
		repoLocation = rp;
		url = "jdbc:mysql://" + ipAddress + "/" + database;
		try {
			connection = DriverManager
					// .getConnection("jdbc:mysql://3.82.210.103:3306/MERIDB?user=CS370&password=HelloCat1");
					// .getConnection(url, dbUser, dbUPassword);
					.getConnection("jdbc:mysql://" + ipAddress + "/" + database + "?user=" + dbUser + "&password="
							+ dbUPassword);
			// .getConnection("jdbc:mysql://" + ipAddress+"/MERIDB?"+
			// "user=MERIREMDB&password=MeriandCat8"+"useSSL=true");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public JSONObject toJson(String[] s) {
		JSONObject json = new JSONObject();
		JSONArray jArray = new JSONArray();
		for (int i = 0; i < s.length; i++) {
			jArray.add(s[i]);
		}
		json.put("Parameters", jArray);
		try {
			FileWriter writeFile = new FileWriter("my.json");
			writeFile.write(json.toString());
			writeFile.flush();
			writeFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return json;
	}

	public void processSurveyCampaign(String myFile) {

		try {
			String content = new Scanner(new File(myFile)).useDelimiter("\\Z").next();
			String[] surveyRecord = content.split("##");
			for (int i = 0; i < surveyRecord.length; i++) {
				String[] temp = surveyRecord[i].split("#");

				String userId = temp[0].replace("\n", "").replace("\r", "");
				String surveyId = temp[1];
				String expDate = temp[2];
				String phoneNum = temp[3];

				Date curDate = new Date();
				String userSurveyId = userId + "~" + surveyId + "~" + expDate + "~" + curDate.toString();
				
				if (executeSelectedQuery("getSurveyId", new String[] { surveyId }).equals(surveyId)) {
					String smsMessage = servletLocation + "usrID=" + userId + "&surveyID=" + surveyId;
					
					System.out.println(smsMessage);
				// messageUser(phoneNum, smsMessage);
				// IF message is SUCCESFULLY SENT, we should call executeSelectedQuery.
				// NOTE: Twillio account blocked so we can't show the execution of messageUser method.

				executeSelectedQuery("insertSurveyUserId",new String[] { userSurveyId, expDate, surveyId, userId });
				
				}

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String executeSelectedQuery(String queryType, String[] infoToProcess) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		String strToReturn = "no result yet";//String mainly used for retrieval of information.
		ResultSet rs = null;
		Boolean insert = true;
		//MORE CODE BELLOW

		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(repoLocation);
			doc.getDocumentElement().normalize();
			NodeList queries = doc.getElementsByTagName("query");
			for (int i = 0; i < queries.getLength(); i++) {
				// System.out.println("this is i: " + i);
				Node query = queries.item(i);
				if (query.getNodeType() == Node.ELEMENT_NODE) {
					Element qElem = (Element) query;
					String name = qElem.getAttribute("name");
					if (name.equals(queryType)) {
						i = queries.getLength();// to stop loop.
						Node sql = query.getFirstChild();
						while (sql.getNodeType() != Node.ELEMENT_NODE) { // skip TextNodes
							sql = sql.getNextSibling();
						}
						if (sql.getNodeType() == Node.ELEMENT_NODE) {
							Class.forName(JDBC_DRIVER);
							PreparedStatement ps = connection.prepareStatement(sql.getTextContent());
							qElem = (Element) sql;
							if(qElem.getAttribute("insert").equals("0")){insert = false;}
							//Check if there are any parameter for this sql query.
							if (!qElem.getAttribute("paramNum").equals("0")) {
								sql = sql.getNextSibling();
								while (sql.getNodeType() != Node.ELEMENT_NODE) { // skip TextNodes
									sql = sql.getNextSibling();
								}

								NodeList params = sql.getChildNodes();

								// Viewing inside the JSON object
								//JSONArray jArr = new JSONArray();
								//jArr = (JSONArray) infoToProcess.get("Parameters");
								Node param = params.item(0);;
								for (int e = 0; e < infoToProcess.length; e++) {
									// System.out.println((String) jArr.get(e));

									param = param.getNextSibling();
									while (param != null && param.getNodeType() == 3) { // skip TextNodes
										param = param.getNextSibling();

									}

									if (param.getNodeType() == Node.ELEMENT_NODE) {
										insertParams((e + 1), param.getTextContent(),  infoToProcess[e], ps);

									}

								}
							}

							if (insert) {
								ps.executeUpdate();
								strToReturn = "insertion attempted";
							} else {
								rs = ps.executeQuery();
									
								
								if (rs.next()){
									strToReturn = rs.getString(1);
								
					            } else {
					            	strToReturn = "not found";
					            }
								
					            rs.close();
					            
							}
				            ps.close();
				            			            
						}
					}
				}
			}
		
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DOMException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return strToReturn;
	}

	/**
	 * selectMethod - finds the right method for the inserted parameter.
	 * 
	 * @param dataType
	 * 
	 *                 Note to myself: remember that VARCHARs have their own sizes!!
	 */
	public void insertParams(int index, String dataType, String data, PreparedStatement p) {
		try {
			if (dataType.equals("INT")) {
				p.setInt(index, Integer.parseInt(data));
			} else if (dataType.equals("VARCHAR") || dataType.equals("LONGTEXT") || dataType.equals("DATE")) {
				p.setString(index, data);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * messageUser - Method that sends a message to a survey participant.
	 * 
	 * @param phoN - String with the phone number of the participant (format:
	 *             +1##########)
	 */

	public Boolean messageUser(String phoN, String myText) {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

		try {
			Message message = Message.creator(new PhoneNumber(phoN), new PhoneNumber("+15165486997"), // twilio number
					myText).create();
		} catch (Exception e) {
			// System.out.println(e.getMessage());
			return false;
		}
		// System.out.println(message.getSid());
		return true;
	}

	public void testSSL() throws SQLException, ClassNotFoundException {
		Class.forName(JDBC_DRIVER);
		String sql = "SHOW SESSION STATUS LIKE 'Ssl_cipher';";
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			System.out.println(rs.getNString("Value"));
		}
	}
	/**
	 * isUsed - method that checks if a user has participated in the survey
	 * 
	 * returns true if Survey User participated 
	 */
	public Boolean isUsed(String surveyUser, String QuestionResponse) {
		
		if (executeSelectedQuery("getUserIDfromSurveyUser", new String[] {surveyUser}).equals(executeSelectedQuery("getUserIDfromQResponce", new String[] {QuestionResponse}))) {
			return true;
		}
		
		return false;
	}
	
	
	public static final int DEFAULT_BUFFER_SIZE = 8192;
	private static void copyInputStreamToFile(InputStream inputStream, File file)
            throws IOException {

        // append = false
        try (FileOutputStream outputStream = new FileOutputStream(file, false)) {
            int read;
            byte[] bytes = new byte[DEFAULT_BUFFER_SIZE];
            while ((read = inputStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, read);
            }
        }

    }


	public static void main(String[] args) {
		ConnectToDB ctdb = new ConnectToDB("3.82.210.103:3306", "MERIDB", "CS370", "HelloCat1", new File("sql_repo.xml"));
		// ConnectToDB ctdb = new ConnectToDB("3.82.210.103:3306", "MERIDB",
		// "MERIREMDB", "MeriandCat8");
		
		//ctdb.processSurveyCampaign("/Users/edyler/Downloads/userID.txt");
		
		System.out.println(ctdb.executeSelectedQuery("getSystemDateTime", null));
		
		//ctdb.executeSelectedQuery("insertToQResponceVal", new String[] {"9871511","1","151","A"});

		
		
		//String strToReturn = ctdb.executeSelectedQuery("getExpirationDate", new String[] {"1324", "123"});
		
		
		//System.out.println("Result: " + strToReturn);

		



		
		System.out.println("End of Program.");

	}
	/*
	 * File file1;
				try(OutputStream outputStream = new FileOutputStream(file1)){
				    IOUtils.copy(in, outputStream);
				} catch (FileNotFoundException e) {
				    // handle exception here
				} catch (IOException e) {
				    // handle exception here
				}
	 */
	

}
